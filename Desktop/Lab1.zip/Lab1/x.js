alert("a");
// alert("b")
alert("b");
/* alert("d")
alert("e")
*/
alert("f");